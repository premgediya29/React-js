import logo from './logo.svg';
import './App.css';
import Registration from './Registration';

function App() {
  return (
    <Registration/>
  );
}

export default App;
