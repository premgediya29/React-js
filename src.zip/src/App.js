import logo from './logo.svg';
import './App.css';
import './Counter.css';
import { Provider } from 'react-redux';
import Counter from './Counter';
import { store } from './store';
import React from 'react';

function App() {
  return (
    
    <div>
      <Provider store={store}>
      <Counter/>
      </Provider>
    </div>
    
  )
}

export default App;
