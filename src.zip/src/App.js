import './App.css';
import ApiData from './ApiData';

function App() {
  return (
    <ApiData/>
  );
}

export default App;
