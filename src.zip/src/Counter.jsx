import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { increment, decrement } from './store';
import './Counter.css';

function Counter() {
  const dispatch = useDispatch();
  const count = useSelector((state) => state.count);

  return (
    <div className="counter-container">
      <h1>Counter: {count}</h1>
      <div className="button-group">
        <button className="counter-button" onClick={() => dispatch(increment())}>+</button>
        <button className="counter-button" onClick={() => dispatch(decrement())}>-</button>
      </div>
    </div>
  );
}

export default Counter;
